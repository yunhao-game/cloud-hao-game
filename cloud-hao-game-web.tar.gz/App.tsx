import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, StatusBar } from 'react-native';
import { HomeScreen } from './src/screens/Home/HomeScreen';
import { BattleScreen } from './src/screens/Battle/BattleScreen';
import { heroes } from './src/data/heroes';
import { getFloor } from './src/data/tower';
import { Hero, TowerFloor } from './src/types';

// 简单的状态管理
type Screen = 'home' | 'select' | 'battle' | 'heroes';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [selectedHeroes, setSelectedHeroes] = useState<Hero[]>([]);
  const [currentFloor, setCurrentFloor] = useState(1);
  const [maxFloor, setMaxFloor] = useState(1);

  // 选择英雄
  const toggleHero = (hero: Hero) => {
    const isSelected = selectedHeroes.some(h => h.id === hero.id);
    if (isSelected) {
      setSelectedHeroes(selectedHeroes.filter(h => h.id !== hero.id));
    } else if (selectedHeroes.length < 4) {
      setSelectedHeroes([...selectedHeroes, hero]);
    }
  };

  // 开始游戏
  const startGame = () => {
    if (selectedHeroes.length > 0) {
      setCurrentScreen('battle');
    }
  };

  // 继续游戏
  const continueGame = () => {
    if (selectedHeroes.length > 0) {
      setCurrentScreen('battle');
    } else {
      setCurrentScreen('select');
    }
  };

  // 战斗结束
  const handleBattleEnd = (win: boolean) => {
    if (win) {
      const nextFloor = currentFloor + 1;
      setCurrentFloor(nextFloor);
      if (nextFloor > maxFloor) {
        setMaxFloor(nextFloor);
      }
    }
    setCurrentScreen('home');
  };

  // 渲染选择英雄界面
  const renderSelectScreen = () => {
    const floor = getFloor(currentFloor);
    const enemyCount = floor ? floor.enemyTeam.length : 4;
    
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => setCurrentScreen('home')}>
            <Text style={styles.backText}>← 返回</Text>
          </TouchableOpacity>
          <Text style={styles.titleText}>选择英雄</Text>
          <Text style={styles.enemyText}>敌方: {enemyCount}人</Text>
        </View>

        <View style={styles.selectInfo}>
          <Text style={styles.selectText}>
            已选择: {selectedHeroes.length}/4
          </Text>
          <Text style={styles.floorInfo}>第 {currentFloor} 层</Text>
        </View>

        <ScrollView style={styles.heroList}>
          <View style={styles.heroGrid}>
            {heroes.map(hero => {
              const isSelected = selectedHeroes.some(h => h.id === hero.id);
              return (
                <TouchableOpacity
                  key={hero.id}
                  style={[styles.heroCard, isSelected && styles.heroCardSelected]}
                  onPress={() => toggleHero(hero)}
                >
                  <Text style={styles.heroEmoji}>
                    {hero.faction === 'fire' && '🔥'}
                    {hero.faction === 'water' && '❄️'}
                    {hero.faction === 'wood' && '🌿'}
                    {hero.faction === 'earth' && '⚔️'}
                    {hero.faction === 'wind' && '🌪️'}
                    {hero.faction === 'arcane' && '🔮'}
                    {hero.faction === 'light' && '🛡️'}
                    {hero.faction === 'dark' && '🌑'}
                    {hero.faction === 'thunder' && '⚡'}
                    {hero.faction === 'dragon' && '🐉'}
                    {hero.faction === 'ranger' && '🏹'}
                    {hero.faction === 'mage' && '🧙'}
                    {hero.faction === 'undead' && '💀'}
                    {hero.faction === 'sea' && '🌊'}
                    {hero.faction === 'mountain' && '🏔️'}
                  </Text>
                  <Text style={styles.heroName}>{hero.name}</Text>
                  <Text style={styles.heroJob}>{hero.job}</Text>
                  <Text style={styles.heroCost}>💰{hero.cost}</Text>
                  <Text style={styles.heroStats}>HP:{hero.hp} ATK:{hero.attack}</Text>
                  {isSelected && <Text style={styles.checkmark}>✓</Text>}
                </TouchableOpacity>
              );
            })}
          </View>
        </ScrollView>

        <View style={styles.footer}>
          <TouchableOpacity
            style={[styles.startButton, selectedHeroes.length < 1 && styles.buttonDisabled]}
            onPress={() => setCurrentScreen('battle')}
            disabled={selectedHeroes.length < 1}
          >
            <Text style={styles.startButtonText}>开始战斗</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  // 渲染英雄图鉴
  const renderHeroesScreen = () => (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setCurrentScreen('home')}>
          <Text style={styles.backText}>← 返回</Text>
        </TouchableOpacity>
        <Text style={styles.titleText}>英雄图鉴</Text>
        <Text style={styles.enemyText}>{heroes.length}个</Text>
      </View>

      <ScrollView style={styles.heroList}>
        <View style={styles.heroGrid}>
          {heroes.map(hero => (
            <View key={hero.id} style={styles.heroCardLarge}>
              <Text style={styles.heroEmojiLarge}>
                {hero.faction === 'fire' && '🔥'}
                {hero.faction === 'water' && '❄️'}
                {hero.faction === 'wood' && '🌿'}
                {hero.faction === 'earth' && '⚔️'}
                {hero.faction === 'wind' && '🌪️'}
                {hero.faction === 'arcane' && '🔮'}
                {hero.faction === 'light' && '🛡️'}
                {hero.faction === 'dark' && '🌑'}
                {hero.faction === 'thunder' && '⚡'}
                {hero.faction === 'dragon' && '🐉'}
                {hero.faction === 'ranger' && '🏹'}
                {hero.faction === 'mage' && '🧙'}
                {hero.faction === 'undead' && '💀'}
                {hero.faction === 'sea' && '🌊'}
                {hero.faction === 'mountain' && '🏔️'}
              </Text>
              <Text style={styles.heroNameLarge}>{hero.name}</Text>
              <Text style={styles.heroJobLarge}>{hero.job}</Text>
              <View style={styles.statsRow}>
                <Text style={styles.heroStat}>💰{hero.cost}</Text>
                <Text style={styles.heroStat}>❤️{hero.hp}</Text>
                <Text style={styles.heroStat}>⚔️{hero.attack}</Text>
              </View>
              <Text style={styles.skillText}>{hero.skill.name}</Text>
              <Text style={styles.skillDesc}>{hero.skill.description}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );

  // 根据屏幕状态渲染
  switch (currentScreen) {
    case 'select':
      return renderSelectScreen();
    case 'heroes':
      return renderHeroesScreen();
    case 'battle': {
      // 确保有玩家英雄
      const battleHeroes = selectedHeroes.length > 0 ? selectedHeroes : heroes.slice(0, 4);
      if (battleHeroes.length === 0) {
        return (
          <View style={styles.container}>
            <Text style={styles.errorText}>请先选择英雄！</Text>
            <TouchableOpacity onPress={() => setCurrentScreen('select')}>
              <Text style={styles.backText}>去选英雄</Text>
            </TouchableOpacity>
          </View>
        );
      }
      return (
        <BattleScreen
          currentFloor={currentFloor}
          playerTeam={battleHeroes}
          onBattleEnd={handleBattleEnd}
          onBack={() => setCurrentScreen('home')}
        />
      );
    }
    default:
      return (
        <HomeScreen
          onStartGame={() => setCurrentScreen('select')}
          onViewHeroes={() => setCurrentScreen('heroes')}
          onContinueGame={continueGame}
        />
      );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a2e',
    paddingTop: StatusBar.currentHeight || 0,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#16213e',
  },
  backText: {
    color: '#e94560',
    fontSize: 16,
  },
  titleText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  enemyText: {
    color: '#aaa',
    fontSize: 14,
  },
  selectInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 15,
  },
  selectText: {
    color: '#4ade80',
    fontSize: 18,
    fontWeight: 'bold',
  },
  floorInfo: {
    color: '#e94560',
    fontSize: 18,
    fontWeight: 'bold',
  },
  heroList: {
    flex: 1,
    padding: 10,
  },
  heroGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    justifyContent: 'center',
  },
  heroCard: {
    backgroundColor: '#16213e',
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    width: '47%',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  heroCardSelected: {
    borderColor: '#4ade80',
    backgroundColor: '#1f4068',
  },
  heroEmoji: {
    fontSize: 32,
  },
  heroName: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
    marginTop: 5,
  },
  heroJob: {
    color: '#aaa',
    fontSize: 10,
  },
  heroCost: {
    color: '#ffd700',
    fontSize: 12,
    marginTop: 2,
  },
  heroStats: {
    color: '#666',
    fontSize: 10,
    marginTop: 2,
  },
  checkmark: {
    position: 'absolute',
    top: 5,
    right: 5,
    color: '#4ade80',
    fontSize: 18,
    fontWeight: 'bold',
  },
  heroCardLarge: {
    backgroundColor: '#16213e',
    borderRadius: 12,
    padding: 15,
    alignItems: 'center',
    width: '47%',
    marginBottom: 10,
  },
  heroEmojiLarge: {
    fontSize: 40,
  },
  heroNameLarge: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 5,
  },
  heroJobLarge: {
    color: '#aaa',
    fontSize: 12,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 5,
  },
  heroStat: {
    color: '#ffd700',
    fontSize: 12,
  },
  skillText: {
    color: '#e94560',
    fontSize: 12,
    fontWeight: 'bold',
    marginTop: 8,
  },
  skillDesc: {
    color: '#aaa',
    fontSize: 10,
    marginTop: 2,
    textAlign: 'center',
  },
  footer: {
    padding: 20,
  },
  startButton: {
    backgroundColor: '#e94560',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  startButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  errorText: {
    color: '#e94560',
    fontSize: 18,
    textAlign: 'center',
    marginTop: 100,
    marginBottom: 20,
  },
});
