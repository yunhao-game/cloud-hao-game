import { Hero, Faction, Job } from '../types';

// 15个英雄数据
export const heroes: Hero[] = [
  // 🔥 火系
  {
    id: 'fire_assassin',
    name: '烈焰射手',
    faction: 'fire',
    job: 'assassin',
    hp: 800,
    maxHp: 800,
    attack: 120,
    defense: 30,
    speed: 95,
    range: 2,
    cost: 2,
    skill: {
      name: '烈焰之魂',
      description: '暴击伤害+50%',
      effect: () => {},
    },
  },
  // ❄️ 水系
  {
    id: 'water_mage',
    name: '冰霜法师',
    faction: 'water',
    job: 'mage',
    hp: 600,
    maxHp: 600,
    attack: 100,
    defense: 20,
    speed: 70,
    range: 3,
    cost: 2,
    skill: {
      name: '冰封千里',
      description: '攻击时减速敌人30%',
      effect: () => {},
    },
  },
  // 🌿 木系
  {
    id: 'wood_support',
    name: '森林德鲁伊',
    faction: 'wood',
    job: 'support',
    hp: 700,
    maxHp: 700,
    attack: 60,
    defense: 40,
    speed: 60,
    range: 2,
    cost: 2,
    skill: {
      name: '自然愈合',
      description: '每回合恢复20%最大HP',
      effect: () => {},
    },
  },
  // ⚔️ 土系
  {
    id: 'earth_warrior',
    name: '岩石骑士',
    faction: 'earth',
    job: 'warrior',
    hp: 1200,
    maxHp: 1200,
    attack: 80,
    defense: 80,
    speed: 40,
    range: 1,
    cost: 3,
    skill: {
      name: '大地护甲',
      description: '受到伤害-30%',
      effect: () => {},
    },
  },
  // 🌪️ 风系
  {
    id: 'wind_assassin',
    name: '疾风剑客',
    faction: 'wind',
    job: 'assassin',
    hp: 750,
    maxHp: 750,
    attack: 110,
    defense: 25,
    speed: 100,
    range: 1,
    cost: 2,
    skill: {
      name: '随风闪避',
      description: '30%几率闪避攻击',
      effect: () => {},
    },
  },
  // 🔮 奥系
  {
    id: 'arcane_mage',
    name: '奥术术士',
    faction: 'arcane',
    job: 'mage',
    hp: 550,
    maxHp: 550,
    attack: 130,
    defense: 15,
    speed: 75,
    range: 3,
    cost: 3,
    skill: {
      name: '奥术爆发',
      description: '魔法伤害x1.5',
      effect: () => {},
    },
  },
  // 🛡️ 光系
  {
    id: 'light_warrior',
    name: '圣光骑士',
    faction: 'light',
    job: 'warrior',
    hp: 1000,
    maxHp: 1000,
    attack: 90,
    defense: 60,
    speed: 55,
    range: 1,
    cost: 3,
    skill: {
      name: '圣光普照',
      description: '对暗影单位伤害+50%',
      effect: () => {},
    },
  },
  // 🌑 暗系
  {
    id: 'dark_assassin',
    name: '暗影刺客',
    faction: 'dark',
    job: 'assassin',
    hp: 700,
    maxHp: 700,
    attack: 140,
    defense: 20,
    speed: 90,
    range: 1,
    cost: 3,
    skill: {
      name: '背刺',
      description: '从背后攻击伤害+50%',
      effect: () => {},
    },
  },
  // ⚡ 雷系
  {
    id: 'thunder_mage',
    name: '雷霆法师',
    faction: 'thunder',
    job: 'mage',
    hp: 580,
    maxHp: 580,
    attack: 115,
    defense: 18,
    speed: 80,
    range: 2,
    cost: 2,
    skill: {
      name: '雷击',
      description: '20%几率造成眩晕',
      effect: () => {},
    },
  },
  // 🐉 龙系
  {
    id: 'dragon_warrior',
    name: '龙裔战士',
    faction: 'dragon',
    job: 'warrior',
    hp: 1100,
    maxHp: 1100,
    attack: 100,
    defense: 50,
    speed: 50,
    range: 1,
    cost: 4,
    skill: {
      name: '龙息',
      description: '攻击时附加火焰伤害',
      effect: () => {},
    },
  },
  // 🏹 游系
  {
    id: 'ranger_archer',
    name: '精灵弓手',
    faction: 'ranger',
    job: 'archer',
    hp: 650,
    maxHp: 650,
    attack: 105,
    defense: 25,
    speed: 85,
    range: 4,
    cost: 2,
    skill: {
      name: '精准射击',
      description: '必中攻击',
      effect: () => {},
    },
  },
  // 🧙 法系
  {
    id: 'mage_mage',
    name: '神秘法师',
    faction: 'mage',
    job: 'mage',
    hp: 520,
    maxHp: 520,
    attack: 145,
    defense: 12,
    speed: 65,
    range: 3,
    cost: 4,
    skill: {
      name: '变形术',
      description: '30%几率使敌人无法行动1回合',
      effect: () => {},
    },
  },
  // 💀 死系
  {
    id: 'undead_warrior',
    name: '亡灵骑士',
    faction: 'undead',
    job: 'warrior',
    hp: 900,
    maxHp: 900,
    attack: 95,
    defense: 45,
    speed: 45,
    range: 1,
    cost: 3,
    skill: {
      name: '亡灵复苏',
      description: '死亡时30%几率复活并恢复50%HP',
      effect: () => {},
    },
  },
  // 🌊 海系
  {
    id: 'sea_support',
    name: '海妖歌者',
    faction: 'sea',
    job: 'support',
    hp: 720,
    maxHp: 720,
    attack: 70,
    defense: 35,
    speed: 70,
    range: 2,
    cost: 2,
    skill: {
      name: '魅惑',
      description: '使敌人攻击自己人1回合',
      effect: () => {},
    },
  },
  // 🏔️ 山系
  {
    id: 'mountain_tank',
    name: '山岭巨人',
    faction: 'mountain',
    job: 'tank',
    hp: 1500,
    maxHp: 1500,
    attack: 60,
    defense: 100,
    speed: 30,
    range: 1,
    cost: 4,
    skill: {
      name: '嘲讽',
      description: '强制所有敌人攻击自己',
      effect: () => {},
    },
  },
];

// 获取所有英雄
export const getAllHeroes = (): Hero[] => heroes;

// 根据ID获取英雄
export const getHeroById = (id: string): Hero | undefined => 
  heroes.find(h => h.id === id);

// 根据阵营获取英雄
export const getHeroesByFaction = (faction: Faction): Hero[] => 
  heroes.filter(h => h.faction === faction);

// 根据职业获取英雄
export const getHeroesByJob = (job: Job): Hero[] => 
  heroes.filter(h => h.job === job);
