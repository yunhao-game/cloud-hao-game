import { TowerFloor, Hero } from '../types';
import { getHeroById } from './heroes';

// 塔层数据
export const towerFloors: TowerFloor[] = [
  {
    floor: 1,
    name: '第一层',
    description: '初入试炼之地',
    enemyTeam: ['fire_assassin', 'wind_assassin'].map(id => getHeroById(id)!) as Hero[],
  },
  {
    floor: 2,
    name: '第二层',
    description: '元素试炼',
    enemyTeam: ['fire_assassin', 'water_mage', 'thunder_mage'].map(id => getHeroById(id)!) as Hero[],
  },
  {
    floor: 3,
    name: '第三层',
    description: '自然之力',
    enemyTeam: ['wood_support', 'earth_warrior', 'ranger_archer'].map(id => getHeroById(id)!) as Hero[],
  },
  {
    floor: 4,
    name: '第四层',
    description: '光明与暗影',
    enemyTeam: ['light_warrior', 'dark_assassin', 'arcane_mage'].map(id => getHeroById(id)!) as Hero[],
  },
  {
    floor: 5,
    name: '第五层',
    description: '龙之巢穴',
    enemyTeam: ['dragon_warrior', 'fire_assassin', 'thunder_mage'].map(id => getHeroById(id)!) as Hero[],
  },
  {
    floor: 6,
    name: '第六层',
    description: '深海恐惧',
    enemyTeam: ['sea_support', 'water_mage', 'undead_warrior'].map(id => getHeroById(id)!) as Hero[],
  },
  {
    floor: 7,
    name: '第七层',
    description: '亡灵大军',
    enemyTeam: ['undead_warrior', 'dark_assassin', 'mountain_tank'].map(id => getHeroById(id)!) as Hero[],
  },
  {
    floor: 8,
    name: '第八层',
    description: '山岭守护',
    enemyTeam: ['mountain_tank', 'earth_warrior', 'ranger_archer'].map(id => getHeroById(id)!) as Hero[],
  },
  {
    floor: 9,
    name: '第九层',
    description: '终极试炼',
    enemyTeam: ['dragon_warrior', 'light_warrior', 'mage_mage', 'sea_support'].map(id => getHeroById(id)!) as Hero[],
  },
  {
    floor: 10,
    name: '第十层',
    description: '云端之巅',
    enemyTeam: ['dragon_warrior', 'mage_mage', 'mountain_tank', 'undead_warrior', 'arcane_mage'].map(id => getHeroById(id)!) as Hero[],
  },
];

// 获取指定层数的信息
export const getFloor = (floor: number): TowerFloor | undefined => 
  towerFloors.find(f => f.floor === floor);

// 获取总层数
export const getTotalFloors = (): number => towerFloors.length;
