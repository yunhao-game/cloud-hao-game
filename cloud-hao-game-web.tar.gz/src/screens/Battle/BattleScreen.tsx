import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { BattleState, BattleUnit, Hero } from '../../types';
import { createBattleUnit, executeRound, checkBattleEnd } from '../../game/battle';
import { getFloor } from '../../data/tower';

interface BattleScreenProps {
  currentFloor: number;
  playerTeam: Hero[];
  onBattleEnd: (win: boolean) => void;
  onBack: () => void;
}

const BOARD_WIDTH = 4;
const BOARD_HEIGHT = 3;

export const BattleScreen: React.FC<BattleScreenProps> = ({
  currentFloor,
  playerTeam,
  onBattleEnd,
  onBack,
}) => {
  const [battleState, setBattleState] = useState<BattleState | null>(null);
  const [battleResult, setBattleResult] = useState<'player' | 'enemy' | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [initError, setInitError] = useState<string | null>(null);

  // 初始化战斗
  useEffect(() => {
    // 防止重复初始化
    if (battleState) return;
    
    try {
      const floor = getFloor(currentFloor);
      if (!floor || !floor.enemyTeam || floor.enemyTeam.length === 0) {
        setInitError('找不到楼层数据: ' + currentFloor);
        return;
      }

      // 确保 playerTeam 有数据
      if (!playerTeam || playerTeam.length === 0) {
        setInitError('请先选择英雄');
        return;
      }

      // 过滤掉无效的英雄数据
      const validPlayerTeam = playerTeam.filter(h => h && h.id && h.name);
      const validEnemyTeam = floor.enemyTeam.filter(h => h && h.id && h.name);
      
      if (validPlayerTeam.length === 0) {
        setInitError('玩家英雄数据无效');
        return;
      }
      
      if (validEnemyTeam.length === 0) {
        setInitError('敌方英雄数据无效');
        return;
      }

      // 创建玩家单位（棋盘左侧）
      const playerUnits: BattleUnit[] = validPlayerTeam.slice(0, 4).map((hero, index) => 
        createBattleUnit(hero, index % 2, Math.floor(index / 2), true)
      );

      // 创建敌方单位（棋盘右侧）
      const enemyUnits: BattleUnit[] = validEnemyTeam.slice(0, 4).map((hero, index) =>
        createBattleUnit(hero, BOARD_WIDTH - 1 - (index % 2), Math.floor(index / 2), false)
      );

      setBattleState({
        playerUnits,
        enemyUnits,
        round: 0,
        isPlayerTurn: true,
        battleLog: [`战斗开始！第 ${currentFloor} 层 - ${floor.name}`],
      });
    } catch (error: any) {
      setInitError('初始化失败: ' + (error?.message || '未知错误'));
    }
  }, [currentFloor, playerTeam]);

  // 执行战斗回合
  const handleNextRound = () => {
    if (!battleState || isProcessing) return;
    
    setIsProcessing(true);
    
    // 延迟执行，让玩家看到战斗过程
    setTimeout(() => {
      if (!battleState) return;
      
      const newState = executeRound(battleState, BOARD_WIDTH, BOARD_HEIGHT);
      const result = checkBattleEnd(newState);
      
      setBattleState(newState);
      
      if (result === 'player') {
        setBattleResult('player');
      } else if (result === 'enemy') {
        setBattleResult('enemy');
      }
      
      setIsProcessing(false);
    }, 500);
  };

  // 渲染棋盘格子
  const renderCell = (x: number, y: number) => {
    const playerUnit = battleState?.playerUnits.find(u => u.x === x && u.y === y && !u.isDead);
    const enemyUnit = battleState?.enemyUnits.find(u => u.x === x && u.y === y && !u.isDead);
    const unit = playerUnit || enemyUnit;
    
    return (
      <View key={`${x}-${y}`} style={[styles.cell, unit ? styles.cellOccupied : styles.cellEmpty]}>
        {unit && (
          <View style={[styles.unit, unit.isPlayer ? styles.playerUnit : styles.enemyUnit]}>
            <Text style={styles.unitEmoji}>
              {unit.hero.faction === 'fire' && '🔥'}
              {unit.hero.faction === 'water' && '❄️'}
              {unit.hero.faction === 'wood' && '🌿'}
              {unit.hero.faction === 'earth' && '⚔️'}
              {unit.hero.faction === 'wind' && '🌪️'}
              {unit.hero.faction === 'arcane' && '🔮'}
              {unit.hero.faction === 'light' && '🛡️'}
              {unit.hero.faction === 'dark' && '🌑'}
              {unit.hero.faction === 'thunder' && '⚡'}
              {unit.hero.faction === 'dragon' && '🐉'}
              {unit.hero.faction === 'ranger' && '🏹'}
              {unit.hero.faction === 'mage' && '🧙'}
              {unit.hero.faction === 'undead' && '💀'}
              {unit.hero.faction === 'sea' && '🌊'}
              {unit.hero.faction === 'mountain' && '🏔️'}
            </Text>
            <Text style={styles.unitHp}>
              {unit.hero.maxHp ? Math.round((unit.currentHp / unit.hero.maxHp) * 100) : 0}%
            </Text>
          </View>
        )}
      </View>
    );
  };

  // 显示初始化错误
  if (initError) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>{initError}</Text>
        <TouchableOpacity style={styles.backButton} onPress={onBack}>
          <Text style={styles.backButtonText}>返回</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (!battleState) {
    return (
      <View style={styles.container}>
        <Text style={styles.loading}>加载战斗...</Text>
        <TouchableOpacity style={styles.backButton} onPress={onBack}>
          <Text style={styles.backButtonText}>返回</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // 战斗结束界面
  if (battleResult) {
    return (
      <View style={styles.container}>
        <View style={styles.resultContainer}>
          <Text style={styles.resultEmoji}>
            {battleResult === 'player' ? '🎉' : '💔'}
          </Text>
          <Text style={styles.resultText}>
            {battleResult === 'player' ? '胜利！' : '失败...'}
          </Text>
          <Text style={styles.resultSubtext}>
            {battleResult === 'player' 
              ? `恭喜通过第 ${currentFloor} 层！`
              : '再接再厉！'}
          </Text>
          
          <TouchableOpacity 
            style={styles.resultButton}
            onPress={() => onBattleEnd(battleResult === 'player')}
          >
            <Text style={styles.resultButtonText}>
              {battleResult === 'player' ? '下一层' : '重新挑战'}
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.backButton}
            onPress={onBack}
          >
            <Text style={styles.backButtonText}>返回主菜单</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* 顶部信息 */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Text style={styles.backText}>← 返回</Text>
        </TouchableOpacity>
        <Text style={styles.floorText}>第 {currentFloor} 层</Text>
        <Text style={styles.roundText}>第 {battleState.round + 1} 轮</Text>
      </View>

      {/* 棋盘 */}
      <View style={styles.board}>
        {Array.from({ length: BOARD_HEIGHT }).map((_, y) => (
          <View key={y} style={styles.row}>
            {Array.from({ length: BOARD_WIDTH }).map((_, x) => renderCell(x, y))}
          </View>
        ))}
      </View>

      {/* 战斗信息 */}
      <View style={styles.battleInfo}>
        <View style={styles.teamInfo}>
          <Text style={styles.teamLabel}>我方</Text>
          <Text style={styles.teamCount}>
            {battleState.playerUnits.filter(u => !u.isDead).length} 人
          </Text>
        </View>
        <View style={styles.vsContainer}>
          <Text style={styles.vsText}>VS</Text>
        </View>
        <View style={styles.teamInfo}>
          <Text style={styles.teamLabel}>敌方</Text>
          <Text style={styles.teamCount}>
            {battleState.enemyUnits.filter(u => !u.isDead).length} 人
          </Text>
        </View>
      </View>

      {/* 操作按钮 */}
      <View style={styles.actionContainer}>
        <TouchableOpacity 
          style={[styles.nextButton, isProcessing && styles.buttonDisabled]}
          onPress={handleNextRound}
          disabled={isProcessing}
        >
          <Text style={styles.nextButtonText}>
            {isProcessing ? '战斗进行中...' : battleState.round === 0 ? '开始战斗' : '下一轮'}
          </Text>
        </TouchableOpacity>
      </View>

      {/* 战斗日志 */}
      <ScrollView style={styles.logContainer}>
        {battleState.battleLog.slice(-5).map((log, index) => (
          <Text key={index} style={styles.logText}>{log}</Text>
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a2e',
  },
  loading: {
    color: '#fff',
    fontSize: 18,
    textAlign: 'center',
    marginTop: 100,
  },
  errorText: {
    color: '#e94560',
    fontSize: 18,
    textAlign: 'center',
    marginTop: 100,
    marginBottom: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#16213e',
  },
  backText: {
    color: '#e94560',
    fontSize: 16,
  },
  floorText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  roundText: {
    color: '#aaa',
    fontSize: 14,
  },
  board: {
    padding: 20,
    gap: 10,
  },
  row: {
    flexDirection: 'row',
    gap: 10,
  },
  cell: {
    width: 75,
    height: 75,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cellEmpty: {
    backgroundColor: '#16213e',
    borderWidth: 1,
    borderColor: '#333',
  },
  cellOccupied: {
    backgroundColor: '#1f4068',
    borderWidth: 2,
  },
  unit: {
    alignItems: 'center',
  },
  playerUnit: {
    borderColor: '#4ade80',
  },
  enemyUnit: {
    borderColor: '#e94560',
  },
  unitEmoji: {
    fontSize: 28,
  },
  unitHp: {
    color: '#fff',
    fontSize: 10,
    marginTop: 2,
  },
  battleInfo: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#16213e',
    marginHorizontal: 20,
    borderRadius: 12,
  },
  teamInfo: {
    alignItems: 'center',
  },
  teamLabel: {
    color: '#aaa',
    fontSize: 12,
  },
  teamCount: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  vsContainer: {
    backgroundColor: '#e94560',
    borderRadius: 20,
    paddingHorizontal: 15,
    paddingVertical: 5,
  },
  vsText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  actionContainer: {
    padding: 20,
  },
  nextButton: {
    backgroundColor: '#e94560',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  nextButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  logContainer: {
    flex: 1,
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  logText: {
    color: '#aaa',
    fontSize: 12,
    marginBottom: 4,
  },
  resultContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  resultEmoji: {
    fontSize: 80,
    marginBottom: 20,
  },
  resultText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
  },
  resultSubtext: {
    fontSize: 18,
    color: '#aaa',
    marginBottom: 40,
  },
  resultButton: {
    backgroundColor: '#e94560',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 40,
    marginBottom: 15,
  },
  resultButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  backButton: {
    paddingVertical: 12,
  },
  backButtonText: {
    color: '#aaa',
    fontSize: 16,
  },
});

export default BattleScreen;
