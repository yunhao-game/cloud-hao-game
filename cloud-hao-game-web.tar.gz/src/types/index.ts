// 英雄类型
export interface Hero {
  id: string;
  name: string;
  faction: Faction;
  job: Job;
  hp: number;
  maxHp: number;
  attack: number;
  defense: number;
  speed: number;
  range: number; // 攻击范围 1=近战, 2=远程
  cost: number; // 费用
  skill: Skill;
  image?: string;
}

export type Faction = 
  | 'fire'    // 火
  | 'water'   // 水
  | 'wood'    // 木
  | 'earth'   // 土
  | 'wind'    // 风
  | 'arcane'  // 奥
  | 'light'   // 光
  | 'dark'    // 暗
  | 'thunder' // 雷
  | 'dragon'  // 龙
  | 'ranger'  // 游
  | 'mage'    // 法
  | 'undead'  // 死
  | 'sea'     // 海
  | 'mountain'; // 山

export type Job = 
  | 'assassin' // 刺客
  | 'mage'     // 法师
  | 'support'  // 辅助
  | 'warrior'  // 战士
  | 'tank'     // 坦克
  | 'archer'   // 射手;

export interface Skill {
  name: string;
  description: string;
  effect: (target: Hero, self: Hero) => void;
}

// 战斗单位（英雄在战场上的实例）
export interface BattleUnit {
  id: string;
  hero: Hero;
  x: number;
  y: number;
  currentHp: number;
  isDead: boolean;
  isPlayer: boolean; // true=玩家单位, false=敌方
}

// 战斗状态
export interface BattleState {
  playerUnits: BattleUnit[];
  enemyUnits: BattleUnit[];
  round: number;
  isPlayerTurn: boolean;
  battleLog: string[];
}

// 塔层信息
export interface TowerFloor {
  floor: number;
  enemyTeam: Hero[];
  name: string;
  description: string;
}

// 游戏存档
export interface GameSave {
  currentFloor: number;
  playerHeroes: Hero[];
  gold: number;
  winCount: number;
  loseCount: number;
}
