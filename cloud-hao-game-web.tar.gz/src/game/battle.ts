import { BattleUnit, BattleState, Hero } from '../types';
import { getHeroById } from '../data/heroes';

// 创建战斗单位
export const createBattleUnit = (
  hero: Hero,
  x: number,
  y: number,
  isPlayer: boolean
): BattleUnit => {
  // 确保 hero 数据完整
  const safeHero = {
    ...hero,
    hp: hero.hp || 100,
    maxHp: hero.maxHp || 100,
    attack: hero.attack || 10,
    defense: hero.defense || 5,
    speed: hero.speed || 50,
    range: hero.range || 1,
    cost: hero.cost || 1,
    skill: hero.skill || { name: '无', description: '无技能', effect: () => {} },
  };

  return {
    id: `${safeHero.id}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    hero: safeHero,
    x,
    y,
    currentHp: safeHero.hp,
    isDead: false,
    isPlayer,
  };
};

// 计算伤害
export const calculateDamage = (attacker: BattleUnit, defender: BattleUnit): number => {
  const baseDamage = attacker.hero.attack;
  const defense = defender.hero.defense;
  const damage = Math.max(1, baseDamage - defense * 0.5 + Math.random() * 20 - 10);
  return Math.floor(damage);
};

// 执行攻击
export const performAttack = (attacker: BattleUnit, defender: BattleUnit): string => {
  if (attacker.isDead || defender.isDead) {
    return `${attacker.hero.name} 无法行动`;
  }

  const damage = calculateDamage(attacker, defender);
  defender.currentHp = Math.max(0, defender.currentHp - damage);
  
  let log = `${attacker.hero.name} 攻击 ${defender.hero.name}，造成 ${damage} 点伤害`;
  
  if (defender.currentHp <= 0) {
    defender.isDead = true;
    log += `，${defender.hero.name} 阵亡！`;
  } else {
    log += `，${defender.hero.name} 剩余 ${defender.currentHp} HP`;
  }
  
  return log;
};

// 查找最近的敌方单位
export const findNearestEnemy = (
  unit: BattleUnit,
  enemies: BattleUnit[]
): BattleUnit | null => {
  const aliveEnemies = enemies.filter(e => !e.isDead);
  if (aliveEnemies.length === 0) return null;
  
  let nearest = aliveEnemies[0];
  let minDist = Infinity;
  
  aliveEnemies.forEach(enemy => {
    const dist = Math.abs(unit.x - enemy.x) + Math.abs(unit.y - enemy.y);
    if (dist < minDist) {
      minDist = dist;
      nearest = enemy;
    }
  });
  
  return nearest;
};

// 移动单位（简单AI：向敌人靠近）
export const moveUnit = (
  unit: BattleUnit,
  enemies: BattleUnit[],
  boardWidth: number,
  boardHeight: number
): void => {
  const target = findNearestEnemy(unit, enemies);
  if (!target) return;
  
  const dx = target.x - unit.x;
  const dy = target.y - unit.y;
  
  // 简单移动逻辑：向目标移动一步
  if (Math.abs(dx) > Math.abs(dy)) {
    unit.x += dx > 0 ? 1 : -1;
  } else if (dy !== 0) {
    unit.y += dy > 0 ? 1 : -1;
  }
  
  // 边界检查
  unit.x = Math.max(0, Math.min(boardWidth - 1, unit.x));
  unit.y = Math.max(0, Math.min(boardHeight - 1, unit.y));
};

// 检查是否在攻击范围内
export const isInAttackRange = (attacker: BattleUnit, target: BattleUnit): boolean => {
  const dist = Math.abs(attacker.x - target.x) + Math.abs(attacker.y - target.y);
  return dist <= attacker.hero.range;
};

// 执行一个单位的回合
export const executeUnitTurn = (
  unit: BattleUnit,
  enemies: BattleUnit[],
  boardWidth: number,
  boardHeight: number
): string[] => {
  const logs: string[] = [];
  
  if (unit.isDead) return logs;
  
  const target = findNearestEnemy(unit, enemies);
  if (!target) {
    logs.push('没有可攻击的目标');
    return logs;
  }
  
  // 如果在攻击范围内，攻击
  if (isInAttackRange(unit, target)) {
    logs.push(performAttack(unit, target));
  } else {
    // 否则移动
    moveUnit(unit, enemies, boardWidth, boardHeight);
    logs.push(`${unit.hero.name} 移动到 (${unit.x}, ${unit.y})`);
    
    // 移动后检查是否可以攻击
    if (isInAttackRange(unit, target)) {
      logs.push(performAttack(unit, target));
    }
  }
  
  return logs;
};

// 检查战斗是否结束
export const checkBattleEnd = (state: BattleState): 'player' | 'enemy' | 'ongoing' => {
  const playerAlive = state.playerUnits.some(u => !u.isDead);
  const enemyAlive = state.enemyUnits.some(u => !u.isDead);
  
  if (!playerAlive && !enemyAlive) return 'ongoing'; // 平局继续
  if (!enemyAlive) return 'player';
  if (!playerAlive) return 'enemy';
  return 'ongoing';
};

// 执行一轮战斗
export const executeRound = (
  state: BattleState,
  boardWidth: number,
  boardHeight: number
): BattleState => {
  const newLog = [...state.battleLog];
  newLog.push(`\n=== 第 ${state.round + 1} 轮 ===`);
  
  // 获取所有存活的单位，按速度排序
  const allUnits = [...state.playerUnits, ...state.enemyUnits]
    .filter(u => !u.isDead)
    .sort((a, b) => b.hero.speed - a.hero.speed);
  
  // 每个单位行动
  allUnits.forEach(unit => {
    const enemies = unit.isPlayer ? state.enemyUnits : state.playerUnits;
    const logs = executeUnitTurn(unit, enemies, boardWidth, boardHeight);
    newLog.push(...logs);
  });
  
  return {
    ...state,
    round: state.round + 1,
    battleLog: newLog,
  };
};
